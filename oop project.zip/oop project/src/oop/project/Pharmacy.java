/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.project;

import java.util.ArrayList;

/**
 *
 * @author hp
 */
public class Pharmacy {
    private String name;
    private ArrayList<drugs1> druglist= new ArrayList();
    Pharmacy(){}
    Pharmacy(String name)
    {
        this.name =name;
    }
    public void add(drugs1 d)
    {
        druglist.add(new drugs1(d.getId(),d.getName()));
    }
    public drugs1 get(int index)
    {
        return druglist.get(index);
    }    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
