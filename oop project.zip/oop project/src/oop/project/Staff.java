/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author hp
 */
public class Staff extends javax.swing.JFrame {


    private static Connection c;
    private static Statement ss;
    private static ResultSet r;
    doctor d = new doctor();
    nurse n = new nurse();
    ArrayList<doctor> dlist = new ArrayList();
    ArrayList<nurse> nlist = new ArrayList();
    public Staff() {
        initComponents();
        show_doctortable();
        show_nursetable();
    }
    public void show_nursetable()
    {
        try{
            c = securedatabase.connect();
            ss = c.createStatement();
            r = ss.executeQuery("select * from nurse");
            DefaultTableModel mm = (DefaultTableModel) nursetable.getModel();
            Object[] row = new Object[4];
            while(r.next())
            {
                nlist.add(new nurse(r.getInt("id"),r.getString("name"),r.getDouble("salary"),r.getInt("work_hours")));
            }
            for(int i=0;i<nlist.size();i++)
            {
                row[0] = nlist.get(i).getId();
                row[1] = nlist.get(i).getName();
                row[2] = nlist.get(i).getSalary();
                row[3] = nlist.get(i).getWork_hours();
                mm.addRow(row);
            }
        }catch(SQLException x)
        {
            JOptionPane.showMessageDialog(rootPane, x.getMessage());
        }
    }

    public void show_doctortable()
    {
        try{
            c = securedatabase.connect();
            ss = c.createStatement();
            r = ss.executeQuery("select * from doctor");
            DefaultTableModel mm = (DefaultTableModel) doctortable.getModel();
            Object[] row = new Object[6];
            while(r.next())
            {
                dlist.add(new doctor(r.getInt("id"),r.getString("name"),r.getDouble("salary"),r.getInt("work_hours"),r.getInt("exeperience")));
            }
            for(int i=0;i<dlist.size();i++)
            {
                String a;
                if(d.replacable(dlist.get(i).getExperience()))
                {
                    a = "yes";
                }
                else{a = "no";}
                row[0] = dlist.get(i).getId();
                row[1] = dlist.get(i).getName();
                row[2] = dlist.get(i).getSalary();
                row[3] = dlist.get(i).getWork_hours();
                row[4] = dlist.get(i).getExperience();
                row[5] = a;
                mm.addRow(row);
            }
        }catch(SQLException x)
        {
            JOptionPane.showMessageDialog(rootPane, x.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        doctortable = new javax.swing.JTable();
        idlabel = new javax.swing.JLabel();
        namelabel = new javax.swing.JLabel();
        explabel = new javax.swing.JLabel();
        doctordelete = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        exp = new javax.swing.JTextField();
        name = new javax.swing.JTextField();
        id = new javax.swing.JTextField();
        work_hourslabel = new javax.swing.JLabel();
        work_hours = new javax.swing.JTextField();
        doctorupdate = new javax.swing.JButton();
        doctoradd = new javax.swing.JButton();
        doctorrefresh = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        nursetable = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        nurseadd = new javax.swing.JButton();
        nurseupdate = new javax.swing.JButton();
        nursedelete = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        nursewh = new javax.swing.JTextField();
        nursename = new javax.swing.JTextField();
        nurseid = new javax.swing.JTextField();
        nurserefrech = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Staff");
        setLocation(new java.awt.Point(360, 140));
        setPreferredSize(new java.awt.Dimension(807, 426));

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));

        doctortable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NAME", "SALARY", "WORK_HOURS", "EXPERIENCE", "REPLACABLE"
            }
        ));
        doctortable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                doctortableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(doctortable);

        idlabel.setForeground(new java.awt.Color(255, 255, 255));
        idlabel.setText("ID");

        namelabel.setForeground(new java.awt.Color(255, 255, 255));
        namelabel.setText("NAME");

        explabel.setForeground(new java.awt.Color(255, 255, 255));
        explabel.setText("EPERIENCE");

        doctordelete.setText("Delete");
        doctordelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                doctordeleteMouseClicked(evt);
            }
        });
        doctordelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doctordeleteActionPerformed(evt);
            }
        });

        jButton4.setText("Back");
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
        });

        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });

        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });

        work_hourslabel.setForeground(new java.awt.Color(255, 255, 255));
        work_hourslabel.setText("WORK_HOURS");

        doctorupdate.setText("Update");
        doctorupdate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                doctorupdateMouseClicked(evt);
            }
        });
        doctorupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doctorupdateActionPerformed(evt);
            }
        });

        doctoradd.setText("Add");
        doctoradd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                doctoraddMouseClicked(evt);
            }
        });
        doctoradd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doctoraddActionPerformed(evt);
            }
        });

        doctorrefresh.setText("Refresh");
        doctorrefresh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                doctorrefreshMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(39, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(doctorrefresh, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                    .addComponent(namelabel, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                    .addComponent(work_hourslabel)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(work_hours, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                    .addComponent(explabel)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(exp, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                    .addComponent(idlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jButton4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(doctoradd, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(doctorupdate, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(doctordelete, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(48, 48, 48))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(idlabel))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(namelabel))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(exp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(explabel))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(work_hours, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(work_hourslabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(doctordelete)
                            .addComponent(doctorupdate)
                            .addComponent(doctoradd))
                        .addGap(18, 18, 18)
                        .addComponent(jButton4))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(doctorrefresh)
                .addGap(73, 73, 73))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Doctor", jPanel1);

        jPanel4.setBackground(new java.awt.Color(0, 0, 0));

        nursetable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NAME", "SALARY", "WORK_HOURS"
            }
        ));
        nursetable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nursetableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(nursetable);

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("ID");

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("NAME");

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("WORK_HOURS");

        nurseadd.setText("Add");
        nurseadd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nurseaddMouseClicked(evt);
            }
        });

        nurseupdate.setText("Update");
        nurseupdate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nurseupdateMouseClicked(evt);
            }
        });

        nursedelete.setText("Delete");
        nursedelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nursedeleteMouseClicked(evt);
            }
        });

        jButton5.setText("Back");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });

        nurserefrech.setText("Refresh");
        nurserefrech.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nurserefrechMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(nursename, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                            .addComponent(nursewh)
                            .addComponent(nurseid)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(nurseadd, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nurseupdate, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nursedelete, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(nurserefrech, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 429, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(61, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(nurseid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(nursename, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(nursewh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(22, 22, 22)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nurseupdate)
                            .addComponent(nurseadd)
                            .addComponent(nursedelete))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton5)
                        .addGap(18, 18, 18)
                        .addComponent(nurserefrech)))
                .addContainerGap(99, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 812, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 428, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Nurse", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nursetableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nursetableMouseClicked
        int x = nursetable.getSelectedRow();
        nurseid.setText(nlist.get(x).getId() +"");
        nursename.setText(nlist.get(x).getName());
        nursewh.setText(nlist.get(x).getWork_hours()+"");
    }//GEN-LAST:event_nursetableMouseClicked

    private void nurseaddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nurseaddMouseClicked
        if(nurseid.getText().equals("") || nursename.getText().equals("") || nursewh.getText().equals(""))
        {
            JOptionPane.showMessageDialog(rootPane, "There is a missing information");
        }
        else{
            try
            {
               c = securedatabase.connect();
               ss = c.createStatement();
               double salary = n.calcsalary(Integer.parseInt(nursewh.getText()));
               ss.execute("insert into nurse values("+nurseid.getText()+",'"+nursename.getText()+"',"+salary+","+nursewh.getText()+")");
               JOptionPane.showMessageDialog(rootPane, "Nurse added succesfully");
            }catch(SQLException x)
            {
                JOptionPane.showMessageDialog(rootPane, x.getMessage());
            }
            
        }
    }//GEN-LAST:event_nurseaddMouseClicked

    private void nurseupdateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nurseupdateMouseClicked
        if(nurseid.getText().equals("") || nursename.getText().equals("") || nursewh.getText().equals(""))
        {
            JOptionPane.showMessageDialog(rootPane, "There is a missing information");
        }
        else
        {
            try
            {
               c = securedatabase.connect();
               ss = c.createStatement();
               double salary = n.calcsalary(Integer.parseInt(nursewh.getText()));
               ss.execute("UPDATE `nurse` SET `name`='"+nursename.getText()+"',work_hours="+nursewh.getText()+",salary="+salary+" WHERE id = "+nurseid.getText()+"");
               JOptionPane.showMessageDialog(rootPane, "Nurse updated succesfully");
            }catch(SQLException x)
            {
                JOptionPane.showMessageDialog(rootPane, x.getMessage());
            }
        }
    }//GEN-LAST:event_nurseupdateMouseClicked

    private void nursedeleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nursedeleteMouseClicked
        if(nurseid.getText().equals(""))
        {
            JOptionPane.showMessageDialog(rootPane, "There is a missing information");
        }
        else
        {
            try
            {
               c = securedatabase.connect();
               ss = c.createStatement();
               ss.execute("DELETE FROM nurse WHERE id ="+nurseid.getText()+"");
               JOptionPane.showMessageDialog(rootPane, "Nurse deleted succesfully");
            }catch(SQLException x)
            {
                JOptionPane.showMessageDialog(rootPane, x.getMessage());
            }
        }    
    }//GEN-LAST:event_nursedeleteMouseClicked

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
        dashboard d = new dashboard();
        this.dispose();
        d.setVisible(true);
    }//GEN-LAST:event_jButton5MouseClicked

    private void nurserefrechMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nurserefrechMouseClicked
        this.dispose();
        Staff s = new Staff();
        s.setVisible(true);
    }//GEN-LAST:event_nurserefrechMouseClicked

    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
        dashboard d = new dashboard();
        this.dispose();
        d.setVisible(true);
    }//GEN-LAST:event_jButton4MouseClicked

    private void doctordeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doctordeleteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_doctordeleteActionPerformed

    private void doctordeleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_doctordeleteMouseClicked
        if(id.getText().equals(""))
        {
            JOptionPane.showMessageDialog(rootPane, "There is a missing information");
        }
        else
        {
            try
            {
               c = securedatabase.connect();
               ss = c.createStatement();
               ss.execute("DELETE FROM doctor WHERE id ="+id.getText()+"");
               JOptionPane.showMessageDialog(rootPane, "Doctor deleted succesfully");
            }catch(SQLException x)
            {
                JOptionPane.showMessageDialog(rootPane, x.getMessage());
            }
        }    
    }//GEN-LAST:event_doctordeleteMouseClicked

    private void doctortableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_doctortableMouseClicked
        int x = doctortable.getSelectedRow();
        id.setText(dlist.get(x).getId() +"");
        name.setText(dlist.get(x).getName());
        exp.setText(dlist.get(x).getExperience()+"");
        work_hours.setText(dlist.get(x).getWork_hours()+"");
    }//GEN-LAST:event_doctortableMouseClicked

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idActionPerformed

    private void doctorupdateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_doctorupdateMouseClicked
        if(id.getText().equals("") || name.getText().equals("") || exp.getText().equals("") || work_hours.getText().equals(""))
        {
            JOptionPane.showMessageDialog(rootPane, "There is a missing information");
        }
        else
        {
            try
            {
               c = securedatabase.connect();
               ss = c.createStatement();
               double salary = d.calcsalary(Integer.parseInt(work_hours.getText()));
               ss.execute("UPDATE `doctor` SET `name`='"+name.getText()+"',`exeperience`="+exp.getText()+" ,work_hours="+work_hours.getText()+",salary="+salary+" WHERE id = "+id.getText()+"");
               JOptionPane.showMessageDialog(rootPane, "Doctor updated succesfully");
            }catch(SQLException x)
            {
                JOptionPane.showMessageDialog(rootPane, x.getMessage());
            }
        }

    }//GEN-LAST:event_doctorupdateMouseClicked

    private void doctorupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doctorupdateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_doctorupdateActionPerformed

    private void doctoraddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_doctoraddMouseClicked
        if(id.getText().equals("") || name.getText().equals("") || exp.getText().equals("") || work_hours.getText().equals(""))
        {
            JOptionPane.showMessageDialog(rootPane, "There is a missing information");
        }
        else{
            try
            {
               c = securedatabase.connect();
               ss = c.createStatement();
               double salary = d.calcsalary(Integer.parseInt(work_hours.getText()));
               ss.execute("insert into doctor values("+id.getText()+",'"+name.getText()+"',"+salary+","+work_hours.getText()+","+exp.getText()+")");
               JOptionPane.showMessageDialog(rootPane, "doctor added succesfully");
            }catch(SQLException x)
            {
                JOptionPane.showMessageDialog(rootPane, x.getMessage());
            }
            
        }
    }//GEN-LAST:event_doctoraddMouseClicked

    private void doctoraddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doctoraddActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_doctoraddActionPerformed

    private void doctorrefreshMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_doctorrefreshMouseClicked
        this.dispose();
        Staff s = new Staff();
        s.setVisible(true);
    }//GEN-LAST:event_doctorrefreshMouseClicked

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Staff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Staff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Staff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Staff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Staff().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton doctoradd;
    private javax.swing.JButton doctordelete;
    private javax.swing.JButton doctorrefresh;
    private javax.swing.JTable doctortable;
    private javax.swing.JButton doctorupdate;
    private javax.swing.JTextField exp;
    private javax.swing.JLabel explabel;
    private javax.swing.JTextField id;
    private javax.swing.JLabel idlabel;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField name;
    private javax.swing.JLabel namelabel;
    private javax.swing.JButton nurseadd;
    private javax.swing.JButton nursedelete;
    private javax.swing.JTextField nurseid;
    private javax.swing.JTextField nursename;
    private javax.swing.JButton nurserefrech;
    private javax.swing.JTable nursetable;
    private javax.swing.JButton nurseupdate;
    private javax.swing.JTextField nursewh;
    private javax.swing.JTextField work_hours;
    private javax.swing.JLabel work_hourslabel;
    // End of variables declaration//GEN-END:variables
}
