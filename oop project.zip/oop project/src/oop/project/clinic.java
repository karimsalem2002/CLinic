/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.project;

import java.util.ArrayList;

/**
 *
 * @author hp
 */
public class clinic {
    private String name;
    private String location;
    Pharmacy p = new Pharmacy();
    ArrayList<staff1> stafflist;
    public clinic(){}
    public clinic(String name ,String location,Pharmacy ph)
    {
        this.name =name;
        this.location = location ;
        this.p.setName(ph.getName());
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    
}
