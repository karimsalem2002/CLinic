/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.project;

/**
 *
 * @author hp
 */
public final class doctor extends staff1 implements replacable{
    private static final int hour_cost = 70;
    private int experience;
    public doctor(){}
    public doctor(int id ,String name, double salary,int wh,int exp)
    {
        super(id,name,salary,wh);
        this.experience = exp;
    }
    public double calcsalary(int h)
    {
        return h*doctor.hour_cost*1.2;
    }
    public boolean replacable(int exp)
    {
        if(exp < 10)
        {
            return true;
        }
        else{return false;}
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }
    
}
