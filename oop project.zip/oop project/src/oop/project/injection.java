/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.project;

/**
 *
 * @author hp
 */
public final class injection extends drugs1{
    private int weight;
    public injection(){}
    public injection(int id,String name,int w)
    {
        super(id,name);
        this.weight = w;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
        
}
