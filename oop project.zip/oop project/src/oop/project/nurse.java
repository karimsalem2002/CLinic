/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.project;

/**
 *
 * @author hp
 */
public final class nurse extends staff1{
    private static final int hour_cost = 50;
    public nurse(){}
    public nurse(int id ,String name, double salary,int wh)
    {
        super(id,name,salary,wh);
    }
    public double calcsalary(int h)
    {
        return h*nurse.hour_cost*1.1;
    }    
}
