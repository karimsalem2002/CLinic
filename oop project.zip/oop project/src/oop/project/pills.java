/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.project;

/**
 *
 * @author hp
 */
public final class pills extends drugs1{
    private int number_of_pills;
    public pills(){}
    public pills(int id,String name,int nop)
    {
        super(id,name);
        this.number_of_pills = nop;
    }

    public int getNumber_of_pills() {
        return number_of_pills;
    }

    public void setNumber_of_pills(int number_of_pills) {
        this.number_of_pills = number_of_pills;
    }
    
}
