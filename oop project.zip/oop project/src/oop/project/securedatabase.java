/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author hp
 */
public class securedatabase {
    private final static String user = "root";
    private final static String password = "";
    private final static String address = "jdbc:mysql://localhost/projectdata";
    public static Connection connect() throws SQLException
    {       
        return DriverManager.getConnection(address, user, password);
    }    
}
