/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.project;

/**
 *
 * @author hp
 */
public abstract class staff1 {
    private int id;
    private String name;
    private double salary;
    private int work_hours;
    public staff1(){}
    public staff1(int id ,String name, double salary,int wh)
    {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.work_hours = wh;
    }
    public abstract double calcsalary(int h);

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getWork_hours() {
        return work_hours;
    }

    public void setWork_hours(int work_hours) {
        this.work_hours = work_hours;
    }
    
}
